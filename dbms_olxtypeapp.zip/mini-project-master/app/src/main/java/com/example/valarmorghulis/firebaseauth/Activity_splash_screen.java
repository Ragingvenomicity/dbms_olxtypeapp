package com.example.valarmorghulis.firebaseauth;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class Activity_splash_screen extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash_screen);
    }
}
